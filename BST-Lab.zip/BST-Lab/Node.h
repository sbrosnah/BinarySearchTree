#pragma once

#include "NodeInterface.h"
using namespace std;

class Node : public NodeInterface {
public:
	Node(int data);
	~Node();

	/*
	* Returns the data that is stored in this node
	*
	* @return the data that is stored in this node.
	*/
	int getData() const;

	void setData(int data);

	/*
	* Returns the left child of this node or null if it doesn't have one.
	*
	* @return the left child of this node or null if it doesn't have one.
	*/
	NodeInterface * getLeftChild() const;

	/*
	* Returns the right child of this node or null if it doesn't have one.
	*
	* @return the right child of this node or null if it doesn't have one.
	*/
	NodeInterface * getRightChild() const;

protected:
	int data;
private:
	Node *leftChild;
	Node *rightChild;
	Node *parent;
	friend class BST;
};