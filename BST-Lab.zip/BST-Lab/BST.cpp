#include "BST.h"

BST::BST() {
	//cout << "In constructor" << endl;
	root = NULL;
	localRoot = NULL;
	previous = NULL;
}

BST::~BST() {
	//cout << "in Destructor" << endl;
	if(root != NULL) {
		clear();
	} else {
		//cout << "already clear" << endl;
	}
}


NodeInterface * BST::getRootNode() const {
	if(root != NULL) {
		return root;
	} else {
		//cout << "ERROR: root is NULL" << endl;
		return NULL;
	}
}

bool BST::traverse(Node *& localRoot, Node *& previous, int data) {
	//cout << "in traverse" << endl;
	if (root != NULL) {
		if(localRoot != NULL && localRoot->data == data) {
			//cout << "data found in tree. don't add" << endl;
			return true;
		} else if(localRoot != NULL && localRoot->data > data){
			//cout << "data is smaller than localRoot" << endl;
			//cout << "current localRoot is not the end. recurse" << endl;
			previous = localRoot;
			localRoot = localRoot->leftChild;
			return traverse(localRoot, previous, data);
		} else if (localRoot != NULL && localRoot->data < data){
			//cout << "data is larger than local Root" << endl;
			//cout << "courrent localRoot is not the end. recurse" << endl;
			previous = localRoot;
			localRoot = localRoot->rightChild;
			return traverse(localRoot, previous, data);
		} else {
			//cout << "at an end. add data here" << endl;
			insert(localRoot, previous, data);
		}
	} else {
		//cout << "no data in tree" << endl;
		insert(localRoot, previous, data);
	}
}

void BST::insert(Node *& localRoot, Node *& previous, int data) {
	if(root == NULL) {
		//cout << "creating a root pointer" << endl;
		root = new Node(data);
		localRoot = root;
	} else {
		//cout << "creating a localRoot" << endl;
		if(previous->data < data) {
			//cout << " at previous' right child" << endl;
			localRoot = new Node(data);
			previous->rightChild = localRoot;
			localRoot->parent = previous;
		} else if (previous->data > data) {
			//cout << " at previous' left child" << endl;
			localRoot = new Node(data);
			previous->leftChild = localRoot;
			localRoot->parent = previous;
		} else {
			//cout << "error in BST::insert. uncaught exceptrion" << endl;
		}
	}
}

bool BST::add(int data) {
	//cout << " in add" << endl;
	localRoot = root;
	previous = root;
	bool inTree = traverse(localRoot, previous, data);
	if(!inTree) {
		return true;
	} else {
		return false;
	} 
}

Node *BST::findRightMost(Node * ptr) {
	if (ptr->rightChild != NULL) {
		ptr = ptr->rightChild;
		findRightMost(ptr);
	} else {
		//cout << "right most node is " << ptr->data << endl;
		return ptr;
	}
} 

bool BST::find(Node *& localRoot, Node *& previous, int data) {
	//cout << "finding..." << endl;
	if(localRoot != NULL && localRoot->data == data) {
		//cout << "found; local are previous roots are set" << endl;
		return true;
	} else {
		if(localRoot != NULL && data < localRoot->data) {
			//cout << "data is less than local root and local root has left child... recurse" << endl;
			previous = localRoot;
			localRoot = localRoot->leftChild;
			find(localRoot, previous, data);
		} else if(localRoot != NULL && data > localRoot->data){
			//cout << "data is greater than localRoot and localRoot has rightChild... recurse" << endl;
			previous = localRoot;
			localRoot = localRoot->rightChild;
			find(localRoot, previous, data);
		} else {
			//cout << "not found" << endl;
			if(root != NULL) {
				//cout << "set localRoot back to root for next time" << endl;
				localRoot = root;
			} else {
				//cout << "tree is empty; set all else to NULL" << endl;
				previous = NULL;
				localRoot = NULL;
			}
			return false;
		} 
	} 
}

/* 
rearranges the data to the right of a localRoot that was removed which had two children. 
*/
void BST::erase(Node *& local, Node *& prev) {
	//cout << "in erase" << endl;
	if(local->leftChild == NULL && local->rightChild == NULL) {
		//cout << "local has no children" << endl;
		if(local->parent != prev) {
			//cout << "local's parent is not prev" << endl;
			local->parent->rightChild = NULL;
			delete local;
			return;
		} else {
			local->parent->leftChild = NULL;
			delete local;
			return;
		}
	} else {
		//cout << "local has children" << endl;
		//cout << "local has a left child" << endl;
		if(local->parent != prev) {
			//cout << "local's parent is not prev" << endl;
			local->parent->rightChild = local->leftChild;
			local->leftChild->parent = local->parent;
			delete local;
			return;
		} else {
			//cout << "local's parent is prev" << endl;
			prev->leftChild = local->leftChild;
			local->leftChild->parent = prev;
			delete local;
			return;
		}
	}	
}

bool BST::remove(int data) {
	localRoot = root;
	previous = root;
	bool found = find(localRoot, previous, data);
	if(found) {
		if(localRoot->leftChild != NULL && localRoot->rightChild != NULL) {
			//cout << "there are two children" << endl;
			Node * largestRightChild = findRightMost(localRoot->leftChild);
			localRoot->data = largestRightChild->data;
			erase(largestRightChild, localRoot);
			return true;
		} else if (localRoot->leftChild == NULL && localRoot->rightChild == NULL) {
			//cout << "there are no children" << endl;
			if(localRoot == root) {
				//cout << "deleting last node in tree" << endl;
				clear();
				return true;
			}
			if(localRoot->parent->leftChild != NULL && localRoot->parent->leftChild->data == localRoot->data) {
				//cout << "it's parent is to the right" << endl;
				localRoot->parent->leftChild = NULL;
				delete localRoot;
				return true;
			} else {
				//cout << "it's parent is to the left" << endl;
				localRoot->parent->rightChild = NULL;
				delete localRoot;
				return true;
			}
		} else {
			//cout << "there is one child" << endl;
			if(localRoot->leftChild != NULL) {
				//cout << "it is a leftChild" << endl;
				if(previous->data > localRoot->data) {
					//cout << "parent is to the right" << endl;
					previous->leftChild = localRoot->leftChild;
					localRoot->leftChild->parent = previous;
					delete localRoot;
					return true;
				} else if (previous->data < localRoot->data) {
					//cout << "parent is to the left" <<endl;
					previous->rightChild = localRoot->leftChild;
					localRoot->leftChild->parent = previous;
					delete localRoot;
					return true;
				} else {
					//cout << "we are deleting the root node which has one child" << endl;
					if(localRoot->rightChild != NULL) {
						//cout << "root's rightChild becomes new root" << endl;
						root = localRoot->rightChild;
						localRoot->rightChild->parent = NULL;
						delete localRoot;
						return true;
					} else {
						//cout << "root's leftChild becomes new root" << endl;
						root = localRoot->leftChild;
						localRoot->leftChild->parent = NULL;
						delete previous;
						return true;
					}
				}
			} else {
				//cout << "it is a rightChild" << endl;
				if(previous->data > localRoot->data) {
					//cout << "parent is to the right" << endl;
					previous->leftChild = localRoot->rightChild;
					localRoot->rightChild->parent = previous;
					delete localRoot;
					return true;
				} else if (previous->data < localRoot->data) {
					//cout << "parent is to the left" <<endl;
					previous->rightChild = localRoot->rightChild;
					localRoot->rightChild->parent = previous;
					delete localRoot;
					return true;
				} else {
					//cout << "we are deleting the root node which has one child" << endl;
					if(localRoot->rightChild != NULL) {
						//cout << "root's rightChild becomes new root" << endl;
						root = localRoot->rightChild;
						localRoot->rightChild->parent = NULL;
						delete localRoot;
						return true;
					}
				}
			}
		}
	} else {
		return false;
	}
}

void BST::clear() {
	localRoot = root;
	Node *prev = NULL;
	Node *next;
	Node *temp;
	while(localRoot != NULL) {
		if(prev == localRoot->parent) {
			//cout << "prev is = to localRoot->parent" << endl;
			if(localRoot->leftChild != NULL) {
				//cout << "setting next to left" << endl;
				next = localRoot->leftChild;
				temp = localRoot;
			} else if (localRoot->rightChild != NULL) {
				//cout << "setting next to right" << endl;
				next = localRoot->rightChild;
				temp = localRoot;
			} else {
				if (localRoot->parent != NULL) {
					//cout << "setting next to parent" << endl;
					next = localRoot->parent;
				} else {
					//cout << "setting next to NULL" << endl;
					next = NULL;
				}
				temp = localRoot;
				//cout << "deleting " << localRoot->getData() << endl;
				delete localRoot;
			}
		} else if (prev == localRoot->leftChild) {
			//cout << "prev is == localRoot->leftChild" << endl;
			if(localRoot->rightChild != NULL) {
				//cout << "setting next to right" << endl;
				next = localRoot->rightChild;
				temp = localRoot;
			} else {
				//cout << "setting next to parent" << endl;
				if(localRoot->parent != NULL) {
					//cout << "parent is not null" << endl;
					next = localRoot->parent;
					temp = localRoot;
					//cout << "deleting " << localRoot->getData() << endl;
					delete localRoot;
				} else {
					//cout << "parent is null" << endl;
					next = NULL;
					temp = localRoot;
					//cout << "deleting " << localRoot->getData() << endl;
					delete localRoot;
				}
			}
		} else {
			next = localRoot->parent;
			temp = localRoot;
			//cout << "deleting " << localRoot->getData() << endl;
			delete localRoot;
		}
		prev = temp;
		localRoot = next;
	}
	root = NULL;
}