#ifndef BST_H_
#define BST_H_

#include "BSTInterface.h"
#include "Node.h"
#include <iostream>

class BST : public BSTInterface {
public:
	BST();
	~BST();
	
	NodeInterface * getRootNode() const;
	
	bool add(int data);

	Node *findRightMost(Node * ptr);

	void erase(Node *& local, Node *& prev);

	bool find(Node *& localRoot, Node *& previous, int data);

	void insert(Node *& insertionNode, Node *& previous, int data);

	bool traverse(Node *& localRoot, Node *& previous, int data);

	bool remove(int data);

	void clear();
	
protected:
	Node *root;
	Node *localRoot;
	Node *previous;
};

#endif